class sqlboy():
    def __init__(self) -> None:
        self.a = 1
        self.b = 2
        
    def sum_ab(self):
        return self.a+self.b



